require_relative 'pages/gmail_homepage'

module GmailSite

    def gmail_homepage
        GmailHomepage.new
    end   
end
